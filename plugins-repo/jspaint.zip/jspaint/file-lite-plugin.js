/* JS Paint only. Loaded after app.js, once systemHooks exists. */
(function () {
  function downloadBlob(blob, filename) {
    var url = URL.createObjectURL(blob)
    var a = document.createElement('a')
    a.href = url
    a.download = filename
    a.rel = 'noopener'
    document.body.append(a)
    a.click()
    a.remove()
    setTimeout(function () {
      URL.revokeObjectURL(url)
    }, 1000)
  }

  function installJsPaint() {
    var paint = window
    if (!paint.fileLiteSDK || !paint.systemHooks || typeof paint.open_from_file !== 'function' || paint.__fileLitePaint)
      return
    paint.__fileLitePaint = true
    var openedPath = ''
    var hooks = paint.systemHooks
    var defaultWrite = hooks.writeBlobToHandle

    hooks.writeBlobToHandle = function (fileHandle, blob) {
      if (typeof fileHandle !== 'string' || !fileHandle)
        return defaultWrite(fileHandle, blob)
      return window.fileLiteSDK.writeFile(fileHandle, blob).then(function () {
        return true
      }).catch(function () {
        return false
      })
    }

    hooks.showSaveFileDialog = function (dialogProps) {
      return paint.save_as_prompt({
        dialogTitle: dialogProps.dialogTitle,
        defaultFileName: dialogProps.defaultFileName,
        defaultFileFormatID: dialogProps.defaultFileFormatID,
        formats: dialogProps.formats,
      }).then(function (picked) {
        return dialogProps.getBlob(picked.newFileFormatID).then(function (blob) {
          downloadBlob(blob, picked.newFileName)
          if (dialogProps.savedCallbackUnreliable) {
            dialogProps.savedCallbackUnreliable({
              newFileName: picked.newFileName,
              newFileFormatID: picked.newFileFormatID,
              newFileHandle: openedPath || null,
              newBlob: blob,
            })
          }
        })
      })
    }

    var defaultOpen = hooks.showOpenFileDialog
    hooks.showOpenFileDialog = function (dialogProps) {
      return defaultOpen(dialogProps).then(function (result) {
        if (result && result.file) {
          openedPath = ''
          window.fileLiteSDK.setTitle(result.file.name)
        }
        return result
      })
    }

    if (typeof paint.file_new === 'function') {
      var defaultNew = paint.file_new
      paint.file_new = function () {
        defaultNew()
        openedPath = ''
        window.fileLiteSDK.setTitle('')
      }
    }

    window.fileLiteSDK.onOpen(function (path, name) {
      if (!path || path === openedPath)
        return
      window.fileLiteSDK.readFile(path).then(function (buf) {
        paint.open_from_file(new File([buf], name || 'image'), path)
        openedPath = path
        window.fileLiteSDK.setTitle(name || '')
      }).catch(function (error) {
        console.error('[jspaint] open failed', error)
      })
    })
  }

  installJsPaint()
})()
